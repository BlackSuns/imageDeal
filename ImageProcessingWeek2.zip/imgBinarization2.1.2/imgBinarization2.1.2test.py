# * 图像二值化部分代码*

import numpy as np
from PIL import Image
import matplotlib.pyplot as plt
import cv2 as cv
# 打开图像并转换为灰度图，类型为“L”
# 请完成你的的代码
src = cv.imread('myImg.jpg')
cv.namedWindow('input_image', cv.WINDOW_NORMAL) #设置为WINDOW_NORMAL可以任意缩放
cv.imshow('input_image', src)
img = Image.open('myImg.jpg')
img = np.array(Image.open('myImg.jpg'))
gray = cv.cvtColor(img, cv.COLOR_RGB2GRAY)
# img = np.array(Image.open('myImg.jpg'))
# Image.show()
print(img)
plt.title('hist figure')
arr = img.flatten()  # 数据,a.flatten()把a降到一维
print(arr)
n, bins, patches = plt.hist(arr, bins=256, density=0, facecolor='green')
# n: 直方图向量，是否归一化由参数normed设定
#
# bins: 返回各个bin的区间范围
#
# patches: 返回每个bin里面包含的数据，是一个list
plt.show()
mean = arr.sum() / len(arr)
print("mean:",mean)
ret, binary = cv.threshold(gray, mean, 255, cv.THRESH_BINARY)
cv.namedWindow("binary2", cv.WINDOW_NORMAL)
cv.imshow("binary2", binary)
cv.waitKey(0)
cv.destroyAllWindows()
# 根据直方图确定阈值，绘制二值化图像
# ret_otsu, binary_otsu = cv.threshold(img, 0, 255, cv.THRESH_BINARY | cv.THRESH_OTSU)
# print("二值阈值_otsu: %s" % ret_otsu)
# img = np.where(img[...,:] < 133, 0, 255)
# img2 = Image.fromarray(img)
######
# 请完成你的的代码
# def threshold_binary(src):
#     #把BGR图像转化成灰度图像
#     gray = cv.cvtColor(src, cv.COLOR_BGR2GRAY)
#     #获得灰度直方图以便调整算法的使用
#     plt.hist(src.ravel(), 256, [0, 256])
#     plt.show()
#     #几种二值化方法
#     ret, binary = cv.threshold(gray, 50, 255, cv.THRESH_BINARY)#指定阈值50
#     print("二值阈值: %s" % ret)
#     cv.imshow("threshold_binary", binary)
#     ret_otsu, binary_otsu = cv.threshold(gray, 0, 255, cv.THRESH_BINARY | cv.THRESH_OTSU)
#     print("二值阈值_otsu: %s" %ret_otsu)
#     cv.imshow("threshold_binary_otsu", binary_otsu)
#     ret_tri, binary_tri = cv.threshold(gray, 0, 255, cv.THRESH_BINARY | cv.THRESH_TRIANGLE)
#     print("二值阈值_tri: %s" % ret_tri)
