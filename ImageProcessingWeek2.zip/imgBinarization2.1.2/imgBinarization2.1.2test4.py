
import numpy as np
from PIL import Image
import matplotlib.pyplot as plt
import cv2 as cv


def imgBinarization(image):
    grayImg = cv.cvtColor(image, cv.COLOR_RGB2GRAY)
    img = np.array(image)
    print(img)
    plt.title('hist figure')
    arr = img.flatten()
    print(arr)
    n, bins, patches = plt.hist(arr, bins=256, density=0, facecolor='green')
    plt.show()
    mean = arr.sum() / len(arr)
    print("mean:", mean)
    ret, binary = cv.threshold(grayImg, mean, 255, cv.THRESH_BINARY)
    return binary


src = cv.imread('myImg2.jpg')
cv.namedWindow('input_image', cv.WINDOW_NORMAL)
cv.imshow('input_image', src)
imgBinarization(src)
cv.namedWindow("binary2", cv.WINDOW_NORMAL)
binarizationImg = cv.imshow("binary2",imgBinarization(src) )
cv.waitKey(0)
cv.destroyAllWindows()
