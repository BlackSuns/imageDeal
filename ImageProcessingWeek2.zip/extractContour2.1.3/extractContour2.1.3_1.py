from PIL import Image
from PIL import ImageFilter

myimg = Image.open("myImg2.jpg")
region = (800, 0, 2300, 1200)
myface = myimg.crop(region)
print('截取图像区域的尺寸' + str(myface.size))
def darker(x):
    return x * 2.5
myface = myface.resize((1000, 1000))
#像素加深
myface = Image.eval(myface, darker)


myface = myface.filter(ImageFilter.EDGE_ENHANCE_MORE)
#提取轮廓
myface = myface.filter(ImageFilter.CONTOUR)
#(𝑥,𝑦)=(160,200)
myimg.paste(myface, (2000,500,2000+myface.width,500+myface.height))
myimg.save("脸部轮廓.png")
myimg.show()