 # * RGB分离部分代码*

import numpy as np
from PIL import Image
import matplotlib.pyplot as plt

#设置中文显示
plt.rcParams['font.sans-serif']='fangsong'
plt.rcParams['font.size'] = 14

# open the image
src = Image.open('split2.jpg')

# orignal
plt.subplot(224)
plt.title('原   图')
img = np.array(src)
plt.imshow(img)

# reduce image
plt.subplot(221)
plt.title('R-缩放')
reduceimg = src.resize((50,50))
reduceimg = np.array(reduceimg)
#img[:, :, 0]，其中0表示红色是RGB分量通道0
plt.imshow(reduceimg[:, :, 0], cmap='gray')

# rotate image
plt.subplot(222)
plt.title('G-镜像+旋转')
rotImg180 = src.rotate(180)
rotImg90 = rotImg180.rotate(90)
rotImg = np.array(rotImg90)
plt.imshow(rotImg[:, :, 1], cmap='gray')

# crop image
plt.subplot(223)
plt.title('B-裁剪')
x = 0
y = 60
w = 1000
h = 500
cropImg = src.crop((x, y, x + w, y + h))
cropImg = np.array(cropImg)
plt.imshow(cropImg[:, :, 2], cmap='gray')
plt.show()
